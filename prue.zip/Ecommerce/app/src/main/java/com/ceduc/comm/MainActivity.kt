package com.ceduc.comm

import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity



class MainActivity : AppCompatActivity() {
            // ... (código anterior)
            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContentView(R.layout.activity_main)

                // Agregar listener para cada botón de producto
                val botonProducto1 = findViewById<Button>(R.id.button1)
                botonProducto1.setOnClickListener { // Abrir el formulario para gestionar el producto
                    abrirFormulario(producto1Codigo, producto1Descripcion, producto1Precio)
                }
                val botonProducto2 = findViewById<Button>(R.id.button2)
                botonProducto1.setOnClickListener { // Abrir el formulario para gestionar el producto
                    abrirFormulario(producto2Codigo, producto2Descripcion, producto2Precio)
                }

                val botonProducto3 = findViewById<Button>(R.id.button3)
                botonProducto1.setOnClickListener { // Abrir el formulario para gestionar el producto
                    abrirFormulario(producto3Codigo, producto3Descripcion, producto3Precio)
                }
                val botonProducto4 = findViewById<Button>(R.id.button4)
                botonProducto1.setOnClickListener { // Abrir el formulario para gestionar el producto
                    abrirFormulario(producto1Codigo, producto1Descripcion, producto1Precio)
                }
            }

            private fun abrirFormulario(codigo: String, descripcion: String, precio: Double) {
                // Inicia el activity del formulario y pasa datos
                val intent = Intent(this, FormularioActivity::class.java)
                intent.putExtra("codigo", codigo)
                intent.putExtra("descripcion", descripcion)
                intent.putExtra("precio", precio)
                startActivity(intent)
            } // ... (código posterior)
        }

    }
}